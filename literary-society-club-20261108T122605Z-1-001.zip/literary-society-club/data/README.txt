Os dados de exemplo são definidos em js/store.js. O painel administrativo salva os dados no localStorage deste navegador. Exporte um backup JSON antes de limpar os dados do navegador.
