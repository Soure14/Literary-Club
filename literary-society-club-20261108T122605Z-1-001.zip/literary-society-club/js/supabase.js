const SUPABASE_URL = "https://kqoajpzaijtvozpwzacn.supabase.co";

const SUPABASE_KEY = "sb_publishable_VfA8RJ6cY9n_jnf59aS_hA_9NAxQoTb";

window.supabaseClient = window.supabase.createClient(
  SUPABASE_URL,
  SUPABASE_KEY
);