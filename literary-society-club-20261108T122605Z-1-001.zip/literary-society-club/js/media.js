
(() => {
  const DB_NAME = "slc_media_db";
  const STORE_NAME = "files";
  const DB_VERSION = 1;
  const urlCache = new Map();

  function openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;

        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: "id" });
        }
      };

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async function save(file, category = "general") {
    if (!(file instanceof Blob)) {
      throw new Error("Arquivo inválido.");
    }

    const db = await openDB();
    const id = "media_" + (
      crypto.randomUUID
        ? crypto.randomUUID()
        : Date.now() + "_" + Math.random().toString(36).slice(2)
    );

    const record = {
      id,
      name: file.name || "arquivo",
      type: file.type || "application/octet-stream",
      category,
      blob: file,
      createdAt: new Date().toISOString()
    };

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).add(record);

      tx.oncomplete = () => {
        db.close();
        resolve(id);
      };

      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    });
  }

  async function get(id) {
    const db = await openDB();

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).get(id);

      request.onsuccess = () => {
        db.close();
        resolve(request.result || null);
      };

      request.onerror = () => {
        db.close();
        reject(request.error);
      };
    });
  }

  async function getURL(id) {
    if (!id) return "";

    if (urlCache.has(id)) {
      return urlCache.get(id);
    }

    const record = await get(id);
    if (!record) return "";

    const url = URL.createObjectURL(record.blob);
    urlCache.set(id, url);

    return url;
  }

  async function remove(id) {
    const db = await openDB();

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(id);

      tx.oncomplete = () => {
        db.close();

        if (urlCache.has(id)) {
          URL.revokeObjectURL(urlCache.get(id));
          urlCache.delete(id);
        }

        resolve(true);
      };

      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    });
  }

  async function list(category) {
    const db = await openDB();

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).getAll();

      request.onsuccess = () => {
        const files = request.result || [];
        db.close();

        resolve(
          category
            ? files.filter(file => file.category === category)
            : files
        );
      };

      request.onerror = () => {
        db.close();
        reject(request.error);
      };
    });
  }

  window.SLCMedia = { save, get, getURL, remove, list };
})();
