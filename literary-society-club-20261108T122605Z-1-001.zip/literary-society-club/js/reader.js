(() => {
  const $ = selector => document.querySelector(selector);

  const esc = value => String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[char]));

  async function initReader() {
    const params = new URLSearchParams(window.location.search);
    const bookId = params.get("id");

    if (!bookId) {
      showError("Nenhuma obra foi selecionada.");
      return;
    }

    const data = SLC.get();

    const book = data.books.find(b => String(b.id) === bookId);

    if (!book) {
      showError("Não foi possível encontrar esta obra.");
      return;
    }

    $("#readerTitle").textContent = book.title || "Obra sem título";
    $("#readerAuthor").textContent = book.author || "Autor não informado";
    $("#readerGenre").textContent = book.genre || "Sem gênero";
    $("#readerSynopsis").textContent =
      book.description || "Sinopse não disponível.";

    if (book.cover) {
      $("#readerCover").innerHTML =
        `<img src="${esc(book.cover)}" alt="Capa de ${esc(book.title)}">`;
    }

    if (!book.pdf || !window.SLCMedia) {
      showDocumentError("O arquivo PDF desta obra não está disponível.");
      return;
    }

    try {
      const pdfUrl = await SLCMedia.getURL(book.pdf);

      if (!pdfUrl) {
        showDocumentError("Não foi possível localizar o arquivo PDF.");
        return;
      }

      $("#readerPdf").innerHTML = `
        <iframe
          src="${esc(pdfUrl)}#toolbar=1&navpanes=0"
          title="Leitura de ${esc(book.title)}"
          width="100%"
          height="800"
          loading="lazy">
        </iframe>
      `;

      if (book.allowDownload) {
        const download = $("#readerDownload");
        download.href = pdfUrl;
        download.download = `${(book.title || "obra").replace(/[\\/:*?"<>|]/g, "")}.pdf`;
        download.classList.remove("hidden");
      }

    } catch (error) {
      console.error("Erro ao abrir a obra:", error);
      showDocumentError("Ocorreu um erro ao carregar o documento.");
    }
  }

  function showError(message) {
    $("#readerTitle").textContent = "Obra não encontrada";
    $("#readerAuthor").textContent = message;
    $("#readerGenre").textContent = "";
    $("#readerSynopsis").textContent = "";
    showDocumentError(message);
  }

  function showDocumentError(message) {
    $("#readerPdf").innerHTML = `
      <div class="reader-error">
        <span>✦</span>
        <p>${esc(message)}</p>
        <a href="membros.html#biblioteca" class="button button-outline">
          Voltar à biblioteca
        </a>
      </div>
    `;
  }

  document.addEventListener("DOMContentLoaded", initReader);
})();