
(() => {
  const $ = s => document.querySelector(s);

  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  }[c]));

  let editing = null;
  let toastTimer;

  const configs = {
    books: {
  title: "Obra",
  fields: [
    ["title", "Título"],
    ["author", "Autor"],
    ["genre", "Gênero"],
    ["year", "Ano"],
    ["description", "Sinopse", "textarea"],
    ["cover", "URL/caminho da capa"],
    ["pdf", "Arquivo PDF", "pdf"],
    ["allowDownload", "Permitir download", "checkbox"]
  ]
},

    events: {
      title: "Concurso ou notícia",
      fields: [
        ["title", "Título"],
        ["date", "Data ou período"],
        ["type", "Tipo (Concurso, notícia...)"],
        ["description", "Descrição", "textarea"]
      ]
    },

    winners: {
      title: "Vencedor",
      fields: [
        ["name", "Nome"],
        ["achievement", "Conquista"],
        ["year", "Ano"],
        ["position", "Posição (1, 2 ou 3)", "number"]
      ]
    },

    products: {
      title: "Produto",
      fields: [
        ["name", "Nome"],
        ["description", "Descrição", "textarea"],
        ["type", "Categoria"],
        ["image", "URL/caminho da imagem"]
      ]
    },

    people: {
      title: "Pessoa",
      fields: [
        ["name", "Nome"],
        ["role", "Cargo"],
        ["bio", "Biografia", "textarea"]
      ]
    },

    writers: {
      title: "Escritor",
      fields: [
        ["name", "Nome completo"],
        ["role", "Cargo ou participação na Sociedade"],
        ["bio", "Biografia", "textarea"],
        ["experience", "Experiência literária", "textarea"],
        ["style", "Estilo de escrita", "textarea"],
        ["works", "Obras publicadas ou projetos", "textarea"],
        ["achievements", "Conquistas e reconhecimentos", "textarea"],
        ["photo", "Fotografia de perfil", "file"]
      ]
    }
  };

  function notify(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");

    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 2500);
  }

  function renderList(type) {
    const d = SLC.get();
    const items = d[type] || [];
    const target = $("#admin" + type[0].toUpperCase() + type.slice(1));

    if (!target) return;

    target.innerHTML = items.map((item, i) => {
      const title = item.title || item.name || "Sem título";

      const sub = type === "books"
        ? `${item.author || ""} · ${item.genre || ""}`
        : type === "winners"
        ? `${item.achievement || ""} · ${item.year || ""}`
        : item.role || item.date || item.type || "";

      return `
        <div class="admin-row">
          <div>
            <strong>${esc(title)}</strong>
            <small>${esc(sub)}</small>
          </div>

          <div class="row-actions">
            <button data-edit="${i}">Editar</button>
            <button class="delete" data-delete="${i}">Excluir</button>
          </div>
        </div>
      `;
    }).join("") || '<p class="empty-state">Nenhum registro cadastrado.</p>';

    target.querySelectorAll("[data-edit]").forEach(b => {
      b.onclick = () => openModal(type, Number(b.dataset.edit));
    });

    target.querySelectorAll("[data-delete]").forEach(b => {
      b.onclick = () => {
        if (!confirm("Excluir este registro?")) return;

        const data = SLC.get();
        data[type].splice(Number(b.dataset.delete), 1);

        SLC.save();
        renderAll();
        notify("Registro excluído.");
      };
    });
  }

  async function renderWriters() {
    const target = $("#adminWriters");
    if (!target) return;

    const writers = SLC.get().writers || [];

    if (!writers.length) {
      target.innerHTML = '<p class="empty-state">Nenhum escritor cadastrado.</p>';
      return;
    }

    const rows = await Promise.all(writers.map(async (writer, i) => {
      let photo = "";

      if (writer.photo && window.SLCMedia) {
        photo = await SLCMedia.getURL(writer.photo);
      }

      return `
        <div class="admin-row writer-admin-row">
          ${
            photo
              ? `<img class="writer-admin-photo" src="${esc(photo)}" alt="Fotografia de ${esc(writer.name)}">`
              : `<div class="writer-admin-placeholder">✒</div>`
          }

          <div class="writer-admin-info">
            <strong>${esc(writer.name || "Sem nome")}</strong>
            <small>${esc(writer.role || "Escritor")}</small>
          </div>

          <div class="row-actions">
            <button data-edit="${i}">Editar</button>
            <button class="delete" data-delete="${i}">Excluir</button>
          </div>
        </div>
      `;
    }));

    target.innerHTML = rows.join("");

    target.querySelectorAll("[data-edit]").forEach(b => {
      b.onclick = () => openModal("writers", Number(b.dataset.edit));
    });

    target.querySelectorAll("[data-delete]").forEach(b => {
      b.onclick = async () => {
        if (!confirm("Excluir este escritor?")) return;

        const data = SLC.get();
        const writer = data.writers[Number(b.dataset.delete)];

        data.writers.splice(Number(b.dataset.delete), 1);
        SLC.save();

        if (writer.photo && window.SLCMedia) {
          await SLCMedia.remove(writer.photo);
        }

        renderAll();
        notify("Escritor excluído.");
      };
    });
  }

  function renderAll() {
    Object.keys(configs).forEach(type => {
      if (type !== "writers") renderList(type);
    });

    renderWriters();
  }
console.log("Botão Novo escritor:", $("#addWriter"));
console.log("Função openModal:", typeof openModal);
  function openModal(type, index = null) {
    editing = { type, index };

    const cfg = configs[type];
    const item = index === null ? {} : SLC.get()[type][index];

    $("#modalTitle").textContent =
      (index === null ? "Adicionar " : "Editar ") + cfg.title.toLowerCase();

    $("#modalFields").innerHTML = cfg.fields.map(([key, label, kind]) => {
      if (kind === "textarea") {
        return `
          <label>
            ${label}
            <textarea name="${key}" rows="3">${esc(item[key] || "")}</textarea>
          </label>
        `;
      }
if (kind === "pdf") {
  return `
    <label>
      ${label}
      <input
        name="${key}"
        type="file"
        accept="application/pdf,.pdf"
      >
      <small>
        Selecione o arquivo PDF da obra.
      </small>
      ${item[key]
        ? '<small>Já existe um PDF cadastrado. Envie outro apenas se quiser substituí-lo.</small>'
        : ""}
    </label>
  `;
}

if (kind === "checkbox") {
  return `
    <label class="checkbox-field">
      <input
        name="${key}"
        type="checkbox"
        value="true"
        ${item[key] ? "checked" : ""}
      >
      ${label}
    </label>
  `;
}
      if (kind === "file") {
        return `
          <label>
            ${label}
            <input
              name="${key}"
              type="file"
              accept="image/*"
            >
            <small>Escolha uma imagem do seu computador. Formatos de imagem são aceitos.</small>
            ${item[key] ? '<small>Já existe uma fotografia cadastrada. Selecione outra apenas se quiser substituí-la.</small>' : ""}
          </label>
        `;
      }

      return `
        <label>
          ${label}
          <input
            name="${key}"
            ${kind === "number"
              ? 'type="number" min="1" max="3"'
              : 'type="text"'}
            value="${esc(item[key] || "")}"
          >
        </label>
      `;
    }).join("");

    $("#modal").classList.remove("hidden");
  }

  function close() {
    editing = null;
    $("#modal").classList.add("hidden");
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderAll();

    $(".admin-tabs").querySelectorAll("button").forEach(b => {
      b.onclick = () => {
        $(".admin-tabs .active")?.classList.remove("active");
        b.classList.add("active");

        $(".admin-panel.active")?.classList.remove("active");

        const panel = $("#panel-" + b.dataset.tab);
        if (panel) panel.classList.add("active");
      };
    });

    Object.keys(configs).forEach(type => {
      const button = $("#add" + type[0].toUpperCase() + type.slice(1));

      if (button) {
button.onclick = () => {
  console.log("CLIQUE RECEBIDO:", type);
  openModal(type);
};      }
    });
const closeButton = $("#closeModal");
const cancelButton = $("#cancelModal");
const modal = $("#modal");
const editForm = $("#editForm");

if (closeButton) closeButton.onclick = close;
if (cancelButton) cancelButton.onclick = close;

if (modal) {
  modal.onclick = e => {
    if (e.target === modal) close();
  };
}

if (!editForm) {
  console.error("Não foi encontrado o formulário editForm.");
}
    $("#editForm").onsubmit = async e => {
      e.preventDefault();

      if (!editing) return;

      const formData = new FormData(e.currentTarget);
      const values = Object.fromEntries(formData.entries());

      const type = editing.type;
      const index = editing.index;
      const data = SLC.get();

      if (type === "winners") {
        values.position = Number(values.position) || 1;
      }
if (type === "books") {
  const pdfFile = formData.get("pdf");
  const oldBook = index === null ? null : data.books[index];

  // Checkbox desmarcado também precisa ser salvo.
  values.allowDownload = formData.has("allowDownload");

  // O arquivo será salvo separadamente no IndexedDB.
  delete values.pdf;

  if (pdfFile && pdfFile.size > 0) {
    if (
      pdfFile.type !== "application/pdf" &&
      !pdfFile.name.toLowerCase().endsWith(".pdf")
    ) {
      alert("Selecione um arquivo PDF válido.");
      return;
    }

    if (!window.SLCMedia) {
      alert("O sistema de armazenamento de arquivos não foi carregado.");
      return;
    }

    try {
      values.pdf = await SLCMedia.save(pdfFile, "book-pdf");

      if (oldBook?.pdf) {
        try {
          await SLCMedia.remove(oldBook.pdf);
        } catch (error) {
          console.warn("Não foi possível remover o PDF anterior:", error);
        }
      }
    } catch (error) {
      console.error(error);
      alert("Não foi possível salvar o PDF.");
      return;
    }
  } else if (oldBook?.pdf) {
    values.pdf = oldBook.pdf;
  }
}
     if (type === "writers") {
  const file = formData.get("photo");
  const oldWriter = index === null ? null : data.writers[index];

  delete values.photo;

  if (file && file.size > 0) {
    if (!file.type.startsWith("image/")) {
      alert("Selecione um arquivo de imagem válido.");
      return;
    }

    if (!window.SLCMedia) {
      alert("O sistema de armazenamento de arquivos não foi carregado.");
      return;
    }

    try {
      values.photo = await SLCMedia.save(file, "writer-photo");

      if (oldWriter?.photo) {
        await SLCMedia.remove(oldWriter.photo);
      }
    } catch (error) {
      console.error(error);
      alert("Não foi possível salvar a fotografia.");
      return;
    }
  } else if (oldWriter?.photo) {
    values.photo = oldWriter.photo;
  }
}
      if (index === null) {
        values.id = type[0] + Date.now();
        data[type].push(values);
      } else {
        data[type][index] = {
          ...data[type][index],
          ...values
        };
      }

      SLC.save();
      renderAll();
      close();
      notify("Alterações salvas neste navegador.");
    };

    const form = $("#settingsForm");
    const settings = SLC.get();

    [
      "history",
      "elisabetLore",
      "whatsapp",
      "instagram",
      "facebook",
      "elisabetPhoto"
    ].forEach(k => {
      form.elements[k].value = settings[k] || "";
    });

    form.onsubmit = e => {
      e.preventDefault();

      const data = SLC.get();

      [
        "history",
        "elisabetLore",
        "whatsapp",
        "instagram",
        "facebook",
        "elisabetPhoto"
      ].forEach(k => {
        data[k] = form.elements[k].value.trim();
      });

      SLC.save();
      notify("Configurações salvas.");
    };

    $("#exportData").onclick = () => {
      const blob = new Blob(
        [JSON.stringify(SLC.get(), null, 2)],
        { type: "application/json" }
      );

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");

      a.href = url;
      a.download = "sociedade-literaria-backup.json";
      a.click();

      URL.revokeObjectURL(url);
      notify("Backup exportado.");
    };

    $("#importData").onchange = async e => {
      const file = e.target.files[0];
      if (!file) return;

      try {
        const obj = JSON.parse(await file.text());

        if (!obj || typeof obj !== "object") throw Error();

        SLC.replace(obj);
        renderAll();

        [
          "history",
          "elisabetLore",
          "whatsapp",
          "instagram",
          "facebook",
          "elisabetPhoto"
        ].forEach(k => {
          form.elements[k].value = SLC.get()[k] || "";
        });

        notify("Backup importado.");
      } catch (err) {
        alert("Não foi possível importar. Verifique se o arquivo JSON é válido.");
      }

      e.target.value = "";
    };

    $("#resetData").onclick = () => {
      if (confirm("Restaurar todos os dados de exemplo? Esta ação substitui o conteúdo atual deste navegador.")) {
        SLC.reset();
        renderAll();

        [
          "history",
          "elisabetLore",
          "whatsapp",
          "instagram",
          "facebook",
          "elisabetPhoto"
        ].forEach(k => {
          form.elements[k].value = SLC.get()[k] || "";
        });

        notify("Dados de exemplo restaurados.");
      }
    };
  });
})();
