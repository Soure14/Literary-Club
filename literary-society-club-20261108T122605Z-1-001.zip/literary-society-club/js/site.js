(() => {
const $=s=>document.querySelector(s), esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
let bookRenderId = 0;

async function renderBooks(books) {
  const currentRender = ++bookRenderId;

  const cards = await Promise.all(books.map(async b => {
    let pdfUrl = "";

    if (b.pdf && window.SLCMedia) {
      try {
        pdfUrl = await SLCMedia.getURL(b.pdf);
      } catch (error) {
        console.error("Erro ao carregar PDF:", error);
      }
    }

    const title = esc(b.title);
    const safeFilename = (b.title || "obra")
      .replace(/[\\/:*?"<>|]/g, "")
      .trim() || "obra";

    const readButton = b.id
  ? `<a class="button button-gold" href="leitura.html?id=${encodeURIComponent(b.id)}">Ver obra ↗</a>`
  : `<span class="text-link">Obra sem identificador</span>`;
    const downloadButton = pdfUrl && b.allowDownload
      ? `<a class="button button-outline" href="${esc(pdfUrl)}" download="${esc(safeFilename)}.pdf">Baixar PDF</a>`
      : "";

    return `
      <article class="book-card">
        <div class="book-cover">
          ${b.cover
            ? `<img src="${esc(b.cover)}" alt="Capa de ${title}">`
            : title}
        </div>

        <h3>${title}</h3>
        <p>${esc(b.author)} · ${esc(b.year)}</p>
        <span class="tag">${esc(b.genre)}</span>

        <p class="book-description">
          ${esc(b.description || "Sinopse não disponível.")}
        </p>

        <div class="book-actions">
          ${readButton}
          ${downloadButton}
        </div>
      </article>
    `;
  }));

  // Impede uma busca antiga de sobrescrever uma busca mais recente.
  if (currentRender !== bookRenderId) return;

  $("#bookGrid").innerHTML = cards.join("");
}

function render(){
 const d=SLC.get();
 $("#clubHistory").textContent=d.history;
 $("#elisabetLore").textContent=d.elisabetLore;
 $("#administrators").innerHTML=d.people.map(p=>`
  <article class="person-card">
    <div class="person-photo">
      ${p.photo
        ? `<img src="${esc(p.photo)}" alt="Retrato de ${esc(p.name)}">`
        : `<div class="person-initial">${esc((p.name||"?").charAt(0))}</div>`
      }
    </div>
    <div class="person-info">
      <span class="person-role">${esc(p.role)}</span>
      <h3>${esc(p.name)}</h3>
      <p>${esc(p.bio)}</p>
    </div>
  </article>
`).join("");
 const genres=[...new Set(d.books.map(b=>b.genre).filter(Boolean))], genre=$("#bookGenre"), selected=genre.value;
 genre.innerHTML='<option value="">Todos os gêneros</option>'+genres.map(g=>`<option>${esc(g)}</option>`).join("");genre.value=selected;
 const q=$("#bookSearch").value.toLowerCase(), f=genre.value;
 const books=d.books.filter(b=>(!f||b.genre===f)&&(`${b.title} ${b.author} ${b.genre}`.toLowerCase().includes(q)));
renderBooks(books); $("#bookEmpty").classList.toggle("hidden",books.length>0);
 $("#eventGrid").innerHTML=d.events.map(e=>`<article class="event-card"><span class="event-date">${esc(e.date)}</span><h3>${esc(e.title)}</h3><p>${esc(e.description)}</p><span class="tag">${esc(e.type)}</span></article>`).join("");
 $("#podium").innerHTML=[...d.winners].sort((a,b)=>a.position-b.position).slice(0,3).map(w=>`<article class="podium-card ${w.position===1?"first":w.position===2?"second":"third"}"><div class="podium-medal">${w.position===1?"♛":w.position===2?"✦":"✧"}</div><h3>${esc(w.name)}</h3><p>${esc(w.achievement)}</p><strong>${w.position===1?"1º LUGAR":w.position===2?"2º LUGAR":"3º LUGAR"}</strong></article>`).join("");
 $("#hallRows").innerHTML=[...d.winners].sort((a,b)=>a.position-b.position).map(w=>`<tr><td>${w.position}º</td><td>${esc(w.name)}</td><td>${esc(w.achievement)}</td><td>${esc(w.year)}</td></tr>`).join("");
 $("#productGrid").innerHTML=d.products.map(p=>`<article class="product-card"><div class="product-art">${p.image?`<img src="${esc(p.image)}" alt="${esc(p.name)}">`:"✦"}</div><h3>${esc(p.name)}</h3><p>${esc(p.description)}</p><span class="tag">${esc(p.type)}</span></article>`).join("");
 $("#elisabetPhoto").src=d.elisabetPhoto||"assets/logo-sociedade-literaria.jpeg";
const wa = d.whatsapp;
const message = encodeURIComponent(
  wa?.message || "Olá! Gostaria de conhecer a Sociedade Literária."
);

$("#whatsappPortugal").href = wa?.portugal
  ? `https://wa.me/${wa.portugal}?text=${message}`
  : "#";

$("#whatsappBrasil").href = wa?.brasil
  ? `https://wa.me/${wa.brasil}?text=${message}`
  : "#";

$("#headerJoin").href = "#membro"; $("#socialLinks").innerHTML=[d.instagram?`<a href="${esc(d.instagram)}" target="_blank" rel="noopener">Instagram ↗</a>`:"",d.facebook?`<a href="${esc(d.facebook)}" target="_blank" rel="noopener">Facebook ↗</a>`:""].filter(Boolean).join("")||'<span class="text-link">Redes sociais em breve</span>';
 $("#year").textContent=new Date().getFullYear();
}
document.addEventListener("DOMContentLoaded",()=>{render();$("#bookSearch").addEventListener("input",render);$("#bookGenre").addEventListener("change",render);$(".menu-toggle").addEventListener("click",()=>{$(".main-nav").classList.toggle("open")});document.querySelectorAll(".main-nav a").forEach(a=>a.addEventListener("click",()=>$(".main-nav").classList.remove("open")));window.addEventListener("slc:data-updated",render)});
})();