(() => {
const KEY="slc_site_data_v1";
const defaults={
 elisabetLore:`Elizabeth nasceu dos palpites milagrosos de Elisa Ferrer, uma participante carismática, gente boa e dona de um talento quase sobrenatural para acertar os resultados das dinâmicas do Clube Sociedade Literária. Seja para adivinhar os vencedores dos desafios literários ou dar seus palpites sobre os mais diversos acontecimentos do clube, Elisa parecia ter uma bola de cristal escondida em algum lugar.

O que começou como uma brincadeira em homenagem a seus acertos frequentes acabou se transformando em um quadro memorável do clube, conquistando seu espaço entre as tradições dos eventos. Elizabeth representa o bom humor, a diversão e aquela pitada de mistério que faz todo mundo se perguntar: como ela consegue acertar tanto?

Mais do que uma homenagem à sua ilustre inspiração, Elizabeth é um símbolo da descontração e da amizade que tornam o Clube Sociedade Literária um espaço especial. Sua presença está garantida nos eventos futuros, sempre com o mesmo propósito: divertir os participantes, estimular os palpites e celebrar a brincadeira, sem qualquer compromisso ou envolvimento com questões financeiras.

Afinal, alguns têm talento para escrever histórias, enquanto outros têm o dom de adivinhar seus desfechos. Elisa Ferrer, por sua vez, parece ter os dois: o talento para escrever suas próprias histórias e a habilidade de dar palpites certeiros sobre as histórias dos outros!`,
whatsapp:{
  portugal:"351939572120",
  brasil:"559881569484",
  message:"Olá! Conheci a Sociedade Literária pelo site e gostaria de saber mais sobre como participar do clube!"
},instagram:"https://www.instagram.com/literarysocietyclub?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==",
facebook:"",
elisabetPhoto:"assets/elisabet/Elisabet.jpeg",
 people:[
  {
    name:"Stellen Henderson",
    role:"Fundadora e presidente",
    bio:"Stellen é apaixonada por livros, escrita e criação de histórias. Criadora do Clube Sociedade Literária, gosta de explorar o universo literário tanto como leitora quanto nos bastidores, organizando projetos e concursos que aproximam pessoas através dos livros.",
    photo:"assets/fundadores/Stellen.jpeg"
  },
  {
    name:"Kayky Vasconcelos",
    role:"Administrador e escritor",
    bio:"Kayky Vasconcelos é um escritor e confeiteiro nascido em uma pequena cidade do interior do Maranhão. Apaixonado por histórias de suspense psicológico e dramas da vida real, com uma pitada de humor, acredita que a escrita pode levá-lo a lugares onde jamais imaginou estar. Sua trajetória no Clube Sociedade Literária começou por acaso, quando encontrou no projeto um espaço em que se sentiu acolhido não apenas como pessoa, mas também como alguém que dava seus primeiros passos na literatura. O que começou como a participação de um simples integrante acabou se transformando em algo muito maior: Kayky tornou-se um dos administradores do clube, projeto que considera uma das experiências mais importantes de sua vida. Ao longo dessa jornada, escreveu diversos contos para os desafios literários promovidos pelo grupo e conquistou um lugar especial entre suas próprias histórias com O Natal de Efigênio, conto vencedor de um concurso literário e dedicado à memória de seu avô, com quem compartilhou momentos preciosos e por quem nutre um amor profundo. Mais do que uma conquista, a obra representa uma homenagem a alguém importante em sua vida e simboliza sua evolução como escritor, impulsionada pelo espaço de aprendizado, incentivo e acolhimento que encontrou no próprio clube. Para Kayky, a literatura vai além das histórias que escreve: ela também é feita dos encontros, das oportunidades e das transformações que acontecem ao longo do caminho. E o Clube Sociedade Literária é, sem dúvida, uma das páginas mais significativas dessa trajetória.",
    photo:"assets/fundadores/Kayky.jpeg"}],
    writers:[],
    books:[{id:"b1",title:"Obra de exemplo",author:"Autor a definir",genre:"Literatura",year:"2026",description:"Substitua este registro por uma obra que já passou pelo clube.",cover:""}],
 events:[{id:"e1",title:"Próximo concurso literário",date:"Em breve",description:"As informações do próximo concurso serão anunciadas pela administração.",type:"Concurso"}],
 winners:[{id:"w1",name:"Vencedor(a) a anunciar",achievement:"Primeiro registro",year:"2026",position:1}],
 products:[{id:"p1",name:"Camiseta oficial",description:"Uma lembrança para vestir as cores do clube.",type:"Vestuário",image:""},{id:"p2",name:"Caneca literária",description:"Para acompanhar suas próximas leituras.",type:"Acessório",image:""}]
};
function clone(x){return JSON.parse(JSON.stringify(x))}
function load(){try{const raw=localStorage.getItem(KEY);if(!raw)return clone(defaults);const parsed=JSON.parse(raw);return {...clone(defaults),...parsed}}catch(e){return clone(defaults)}}
let data=load();
function save(){localStorage.setItem(KEY,JSON.stringify(data));window.dispatchEvent(new CustomEvent("slc:data-updated"))}
window.SLC={get:()=>data,save:()=>save(),reset:()=>{data=clone(defaults);save()},replace:value=>{data={...clone(defaults),...value};save()},defaults:clone(defaults)};
})();